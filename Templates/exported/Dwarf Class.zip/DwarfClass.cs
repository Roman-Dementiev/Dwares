﻿using System;
using Dwares.Dwarf;


namespace $rootnamespace$
{
	public class $safeitemname$
	{
		//ClassRef @class = new ClassRef(typeof($safeitemname$));

		public $safeitemname$()
		{
			//Debug.EnableTracing(@class);
		}
	}
}
