﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Dwares.Druid.UI;
using Dwares.Dwarf;


namespace $rootnamespace$
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class $safeitemname$ : ContentPageEx
	{
		public $safeitemname$()
		{
			InitializeComponent();
		}
	}
}